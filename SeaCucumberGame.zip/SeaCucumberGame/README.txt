/************************************************/
/*	Sea Cucumber Game	    	        */
/*	Programmer : Niblet, Amin Khan		*/
/*	Date : 11th May, 2022	                */
/*	Email : akhan2019@elam.co.uk            */
/* 	Webpages : https://niblet.itch.io/	*/
/*             https://github.com/Niblet-0	*/
/* 	Discord : Niblet#7617		        */
/* 	                    		        */
/* 	Made for Teesside university		*/
/* 	Uhh, don't redistribute source code     */
/* 	and other copyright stuff               */
/* 	                                        */
/************************************************/

Version: 1

Future updates: Never.