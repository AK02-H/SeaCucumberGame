SFML 2.5.1 10/01/19
64 Bit Targets Only

Removed some files to reduce size. Full package is available here: https://www.sfml-dev.org/download/sfml/2.5.1/