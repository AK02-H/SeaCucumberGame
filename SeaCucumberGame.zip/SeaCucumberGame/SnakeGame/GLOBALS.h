#pragma once
//class GLOBALS
//{
//public:
//
//	/*static int GRIDSIZE;
//	static int SCREEN_W;
//	static int SCREEN_H;*/
//
//};

#define GRIDSIZE 25
#define SNAKE_OUTLINETHICKNESS 3
#define SCREEN_W 1200
#define SCREEN_H 900
#define SCOREBOARD_W 300
#define TICK 0.13				//DEFAULT: 0.13
#define MAX_FOOD 10
#define GAMELENGTH 90
#define MAX_OXYGEN 150			//DEFAULT: 150

#define FE_SCREEN_W 350
#define FE_SCREEN_H 600

#define RANDBOOL ((rand() % 2) == 0)

