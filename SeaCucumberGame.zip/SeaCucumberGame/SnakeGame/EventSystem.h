#pragma once

class EventSystem {

public:

	typedef void (*callback_function)(void);

	void testFunc() {

	}
};
